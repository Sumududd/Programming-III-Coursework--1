
package newpackage;



public class Payment{
    
    private final double advacepayment=1000;
    


  double totaltratmentcost;
  
 void addingteatment(double trtretmentfeelkr){
     
      totaltratmentcost= totaltratmentcost+trtretmentfeelkr;
         
    }
  public  double getttreatementcost(){
        
      return totaltratmentcost;
        
    }
  
  public double getadvancepayment(){
     
      return advacepayment;
      
}
   public double gettotalamount(){
      
       return totaltratmentcost=totaltratmentcost-advacepayment;
   }
  
   
   public void clearvariable(){
        totaltratmentcost=0;
       
   }
}
