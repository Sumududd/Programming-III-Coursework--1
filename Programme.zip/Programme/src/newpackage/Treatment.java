package newpackage;


public enum Treatment {
    
    CLEANINGS(6000.00),
    WHITENING (8500.00),
    FILLING (15000.00),
    NERVE_FILING (2500.00),
    ROOT_CANEL_THERAPY (30000.00);

    static void values(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
      
        private  final double cost;
        
        
        
         
    Treatment(double cost){
        
       this.cost=cost;
        
    }
    
     
     public  double getcost(){
         
         return cost;
     }
     

    }


