package newpackage;

public class Patient{
 
private int apoimentid;
private String name;
private String telno;
private String address;
private String time;
private String date;
    
    public Patient (int apoimentid,String name,String telno, String address,String time,String date){
    
    this.apoimentid =apoimentid;
    this.name=name;
    this.telno=telno;
    this.address=address;
    this.time=time;
    this.date=date;
    
    }
    
    public int getApoimnetID() {
        return apoimentid;
    }
    
    public String getName() {
        return name;
    }
    public String getTelno() {
        return telno;
    }
    public String getAdress() {
        return address;
    }
    public String getTime() {
        return time;
    }
    public String getDate() {
        return date;
    }
    
    
    
}
 
//Store patent class object in Patientdatalist array lis
     
   
     
     
 



//    
//
// {
//       for(Patient patient:patientdataArray)  {
//           System.out.println(patient.name);
//       }
//}
//}
 
 


    
    
  


 


    


