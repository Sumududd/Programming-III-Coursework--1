package newpackage;


import newpackage.Patient;
import newpackage.Treatment;
import java.util.LinkedList;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Mainframe extends javax.swing.JFrame {
    
    
    
int apoimentID=0 ;  // Varable declaration for apoiment id selection 
String selecteddate;  //Varable declaration for date assighn selected date
int selectdateindex; //Variable for date selection combo box index
int appoimentcount=1; // /Varable declaration for appoiment ID 
String apoimentIDforBilll; //Varable declaration for get current appoiment id for bill caculation
double tretmentcost;// Variable declararion for total tratment cost
 double  advacepayment;//Variable define for assighn the advance payment
 double totalamount; // Variable define assigh total tratment cost
 double sendtretmentcost; // Variable difine for assighn selected each treatment cost 
private boolean butTotalcostAction =false;  //Variable assighn for control tottal cost calculation button repeate control
 
ArrayList<Patient>patientdataArray=new ArrayList<>();// intiatate the array list to store patient  class object
LinkedList<Integer>tretmentindex=new LinkedList(); // intiate array list for save selected treatment index
Treatment[] treatmentarray = Treatment.values(); // create array to store all the treatment deteals retrive from the Treatment class
Payment billcal=new Payment();// create object for Payment class

int timearray[][]={{6,9},{6,9},{3,10},{3,10}}; //Define an array for store time range accoding to the date
   
    public Mainframe() {
        
        initComponents();
        //////////////////////////////////////////////Initiation of the interface details
for(Treatment treatmentitem : Treatment.values()){   //Reasding treatment class treatment detaails 
String  treatment=treatmentitem.toString();          //convert Constant to the string   
comboBoxTreatment.addItem(treatment);    // Put item to treatment selection combo box                 
advancePayment.setText(Double.toString(billcal.getadvancepayment())); //read advancepayment values and print in tex box

}







    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        comboBoxDate = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        txtboxTelno = new javax.swing.JTextField();
        labelAdvancepayment = new javax.swing.JLabel();
        txtboxAddress = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtboxPatientname = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButtonMakeApoiment = new javax.swing.JButton();
        ComboBoxTime = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        txtboxApoimnentID = new javax.swing.JTextField();
        checkboxApoiment = new javax.swing.JCheckBox();
        advancePayment = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        txtboxTotalFee = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtareaBillprint = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        butTotalcost = new javax.swing.JButton();
        butPrintBill = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        comboBoxTreatment = new javax.swing.JComboBox<>();
        addtretment = new javax.swing.JButton();
        jButtonRemoveTreatment = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        texareaTreatmentlist = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        txtboxEnterID = new javax.swing.JTextField();
        comboserchSelectdate = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtareaSearch = new javax.swing.JTextArea();
        butSearch = new javax.swing.JButton();
        butClean = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, -1, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Enter Date or Apoiment ID"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        comboBoxDate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Monday", "Wednsday", "Saturday", "Sunday" }));
        comboBoxDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxDateActionPerformed(evt);
            }
        });
        jPanel1.add(comboBoxDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, -1, -1));

        jLabel6.setText("Enter Address");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, -1, 20));

        txtboxTelno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtboxTelnoActionPerformed(evt);
            }
        });
        jPanel1.add(txtboxTelno, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 110, -1));

        labelAdvancepayment.setText("Advance payment LKR");
        jPanel1.add(labelAdvancepayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, -1, 20));

        txtboxAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtboxAddressActionPerformed(evt);
            }
        });
        jPanel1.add(txtboxAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 50, 160, -1));

        jLabel8.setText("Select Date");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, 20));

        jLabel9.setText("Enter Patient Name");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, 20));
        jPanel1.add(txtboxPatientname, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 150, -1));

        jLabel10.setText("Telephon No");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, 20));

        jButton1.setText("Clear");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 130, -1));

        jButtonMakeApoiment.setText("Make Apoiment");
        jButtonMakeApoiment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMakeApoimentActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonMakeApoiment, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        ComboBoxTime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        ComboBoxTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxTimeActionPerformed(evt);
            }
        });
        jPanel1.add(ComboBoxTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 80, -1));

        jLabel17.setText("Apoiment ID ");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 130, -1, 30));

        txtboxApoimnentID.setBackground(new java.awt.Color(204, 204, 204));
        txtboxApoimnentID.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtboxApoimnentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtboxApoimnentIDActionPerformed(evt);
            }
        });
        jPanel1.add(txtboxApoimnentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, 120, -1));

        checkboxApoiment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkboxApoimentActionPerformed(evt);
            }
        });
        jPanel1.add(checkboxApoiment, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 90, -1, 30));

        advancePayment.setBackground(new java.awt.Color(204, 204, 204));
        advancePayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                advancePaymentActionPerformed(evt);
            }
        });
        jPanel1.add(advancePayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 90, -1, -1));

        jButton2.setText("View timeslot");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 580, 170));
        jPanel1.getAccessibleContext().setAccessibleName("Selet Date or Enter Apoiment ID");

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Payment"));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtboxTotalFee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtboxTotalFeeActionPerformed(evt);
            }
        });
        jPanel5.add(txtboxTotalFee, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, 120, -1));

        txtareaBillprint.setBackground(new java.awt.Color(204, 204, 204));
        txtareaBillprint.setColumns(20);
        txtareaBillprint.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        txtareaBillprint.setRows(5);
        jScrollPane2.setViewportView(txtareaBillprint);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 60, -1, -1));

        jButton4.setText("Clear");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 140, -1));

        butTotalcost.setText("Total bill");
        butTotalcost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butTotalcostActionPerformed(evt);
            }
        });
        jPanel5.add(butTotalcost, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 130, -1));

        butPrintBill.setText("Print Bill");
        butPrintBill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butPrintBillActionPerformed(evt);
            }
        });
        jPanel5.add(butPrintBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 120, -1));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 480, 580, 190));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Treatment ")));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setText("Select Treatment");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        comboBoxTreatment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxTreatmentActionPerformed(evt);
            }
        });
        jPanel4.add(comboBoxTreatment, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 130, -1));

        addtretment.setText("Add");
        addtretment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addtretmentActionPerformed(evt);
            }
        });
        jPanel4.add(addtretment, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 30, 70, 20));

        jButtonRemoveTreatment.setText("Remove");
        jButtonRemoveTreatment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoveTreatmentActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonRemoveTreatment, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, 70, 20));

        texareaTreatmentlist.setColumns(20);
        texareaTreatmentlist.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        texareaTreatmentlist.setRows(5);
        jScrollPane4.setViewportView(texareaTreatmentlist);

        jPanel4.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 220, 60));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 580, 90));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Search "));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtboxEnterID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtboxEnterIDActionPerformed(evt);
            }
        });
        jPanel2.add(txtboxEnterID, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 80, -1));

        comboserchSelectdate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Date", "Monday", "Wednsday", "Saturday", "Sunday" }));
        comboserchSelectdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboserchSelectdateActionPerformed(evt);
            }
        });
        jPanel2.add(comboserchSelectdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jLabel4.setText("Enter Apoiment ID");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, -1, -1));

        txtareaSearch.setColumns(20);
        txtareaSearch.setRows(5);
        jScrollPane1.setViewportView(txtareaSearch);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 540, 90));

        butSearch.setText("Search");
        butSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butSearchActionPerformed(evt);
            }
        });
        jPanel2.add(butSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, -1, -1));

        butClean.setText("Clear");
        butClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butCleanActionPerformed(evt);
            }
        });
        jPanel2.add(butClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 150, 80, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 580, 190));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel1.setText("Tooth Care");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 79, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtboxEnterIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtboxEnterIDActionPerformed
          
    }//GEN-LAST:event_txtboxEnterIDActionPerformed

    private void comboserchSelectdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboserchSelectdateActionPerformed
      
       selecteddate =comboserchSelectdate.getSelectedItem().toString();   //Get selected date from combobox and convert string and assighn to selecteddate variable
       selectdateindex=comboserchSelectdate.getSelectedIndex();//Get selected date combo box index
    }//GEN-LAST:event_comboserchSelectdateActionPerformed

    private void comboBoxDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxDateActionPerformed

    private void txtboxTelnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtboxTelnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtboxTelnoActionPerformed

    private void jButtonMakeApoimentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMakeApoimentActionPerformed
  
        
  txtboxApoimnentID.setText(Integer.toString(appoimentcount));// appoimentID   convert to string and set txtboxApoimnentID text feild
  
  if(true==checkboxApoiment.isSelected()){    // Check whether advance payment accept or not
  
String  name=txtboxPatientname.getText();  //read patient name and assighn to variable
String  telno=txtboxTelno.getText();  //read patient telephone number and assighn to variable
String  address=txtboxAddress.getText(); // read patient address and assighn to variable
String  time=ComboBoxTime.getSelectedItem().toString(); // Combo box item convert to string
String  date = comboBoxDate.getSelectedItem().toString();// Combo box item convert to string
   

   Patient patientdatalist=new Patient( appoimentcount,name,telno,address,time,date); // Create object  "patientdatalist" in the Patiant class
     
  patientdataArray.add(patientdatalist);   // adding object to the array
    appoimentcount++;// appoimentcount increment by one
    
   txtboxPatientname.setText(""); //Clear name 
   txtboxTelno.setText("");// Clear telephone numer 
   txtboxAddress.setText(""); //Clear address
   
    JOptionPane.showMessageDialog(null,"The appointment was successfully saved");
    }//GEN-LAST:event_jButtonMakeApoimentActionPerformed
  else {     //If not advance payment accept generate a massage
      
      
      JOptionPane.showMessageDialog(null,"Please accept advance payment");
  
      
  }
    }
    
    private void txtboxApoimnentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtboxApoimnentIDActionPerformed
     
    }//GEN-LAST:event_txtboxApoimnentIDActionPerformed

    private void txtboxAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtboxAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtboxAddressActionPerformed

    private void butSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butSearchActionPerformed
    billcal.clearvariable();//clear variable of payment class
    texareaTreatmentlist.setText(""); //cleat txt area 
    txtareaSearch.setText("");  //Clear the te
    tretmentindex.clear();    // Clearing the selected treatment list
        String ID =txtboxEnterID.getText();    //Reeading get from apoiment ID enterring text feild
       apoimentIDforBilll=ID;
        
        if (!ID.isEmpty()){                   //Chacking the text feald is emty or not 
        apoimentID=Integer.parseInt(ID);  // String value converter to Integer store in variable.
        }
        
         
        if(0<selectdateindex&&ID.isEmpty()){   //check whether the date has seleced and did entered Apoiment ID 
        
  /////selec base on date
 for (Patient patient : patientdataArray) {           //retrieving object from  patientdataArray arraylink
     if(patient.getDate().equals(selecteddate)) // checking the dates equals to the selected date
     
       txtareaSearch.append("ApID: "+ patient.getApoimnetID()+"   "+"Date:"+patient.getDate()+"    "+"Time: "+ patient.getTime()+"    "+"Name:"+patient.getName()+"   "+"Tel:"+patient.getTelno()+"    "+"Adress:"+patient.getAdress()+"\n");
       
    }
 // clear text area
        } else
            
        {
           ///////////////////////////////////////////////////////////////////
           
            butTotalcostAction =true   ;                               //activate the totalcost calculation
          
            
           for (Patient patient : patientdataArray) {           //retrieving object from  apoiment number
     
              
               if(patient.getApoimnetID()==apoimentID){ // checking enterd appoiment number to the customer appoiment number
     txtareaSearch.setText("");  // Cleat text area 
         
       txtareaSearch.append("ApID: "+ patient.getApoimnetID()+"   "+"Date:"+patient.getDate()+"    "+"Time: "+ patient.getTime()+"    "+"Name:"+patient.getName()+"   "+"Tel:"+patient.getTelno()+"    "+"Adress:"+patient.getAdress()+"\n");
     System.out.println("ApoimnetID"+patient.getApoimnetID() );
     
               }   
    } 
                 
        }
        
     
    }//GEN-LAST:event_butSearchActionPerformed

    private void butCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butCleanActionPerformed
txtboxEnterID.setText("");// Clean the appoiment enter txt box
apoimentID=0;  // resest the apoiment vlue by the user
txtareaSearch.setText("");  // cleaning the txt area
comboserchSelectdate.setSelectedIndex(0); // clene the combo box
txtareaSearch.setText("");
    }//GEN-LAST:event_butCleanActionPerformed

    private void txtboxTotalFeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtboxTotalFeeActionPerformed
      
       

    }//GEN-LAST:event_txtboxTotalFeeActionPerformed

    private void addtretmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addtretmentActionPerformed
        
 butTotalcostAction =true;
      
int i =comboBoxTreatment.getSelectedIndex();//Tratment combo box index value assighn to the variable
tretmentindex.add(i); // add selected treatment to list



Treatment treatmentfee=treatmentarray[i];  //retieve trearmet detail according to the selected tratment
var treatmentname =treatmentfee.toString(); //array component convert to string
texareaTreatmentlist.append(treatmentname+"\n");  // selected tratment type print texarea


    }//GEN-LAST:event_addtretmentActionPerformed

    private void comboBoxTreatmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxTreatmentActionPerformed
        // TODO add your handling code here:
        

    }//GEN-LAST:event_comboBoxTreatmentActionPerformed

    private void jButtonRemoveTreatmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoveTreatmentActionPerformed
         butTotalcostAction =true;
        
        texareaTreatmentlist.setText("");            //Clear treatment list    
        if (!tretmentindex.isEmpty()){      // Check whether selected treatment index array is emty or not
             tretmentindex.removeLast();     // remove last entered treatmet indec
         }

    for(Integer val:tretmentindex)         //retrive rest of index numer
    {
    Treatment treatmentfee=treatmentarray[val];  //retieve trearmet detail according to the selected tratment
    var treatmentname =treatmentfee.toString(); //array component convert to string
    texareaTreatmentlist.append(treatmentname+"\n");  // selected tratment type print text area
 
    }

       
    }//GEN-LAST:event_jButtonRemoveTreatmentActionPerformed

    
    private void butTotalcostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butTotalcostActionPerformed
        
    
       if(butTotalcostAction ==true){
            
        for(Integer val:tretmentindex)         //retrive rest of index numer
    {
     Treatment treatmentfee=treatmentarray[val];  //retrieve trearmet detail according to the selected tratment
    sendtretmentcost =treatmentfee.getcost()  ;   //array component convert to string

  System.out.println("sendtretmentcost="+sendtretmentcost);
  
          billcal.addingteatment(sendtretmentcost);// call methed to get total cost of the treatment
          
 ////////////////////////////////////////////////////////////////////////////////         
          System.out.println("sendtretmentcost"+sendtretmentcost );
       /////////////////////////////////////////////////////////////////////////////    
    }
  
      txtboxTotalFee.setText(Double.toString(billcal.getttreatementcost())); // total cost get and set to a text box
    ////////////////////////////////////////////////////
       System.out.println("gettreatment total cost"+billcal.getttreatementcost() );
       ///////////////////////////////////////////////////////////
     
   
      
      sendtretmentcost=0;
tretmentcost=billcal.getttreatementcost();
advacepayment=billcal.getadvancepayment();
totalamount=billcal.gettotalamount();
      
    billcal.clearvariable();  // clear variable of pament class 
       
       }    
       
       butTotalcostAction =false;     //deactivate the total 
    }//GEN-LAST:event_butTotalcostActionPerformed

    private void butPrintBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butPrintBillActionPerformed
    
      
            
         texareaTreatmentlist.setText("");   
         txtareaBillprint.setText(""); 
         txtareaBillprint.append("                TOOTH CARE  "+"\n");
         txtareaBillprint.append("Apoiment ID :"+ apoimentIDforBilll+"\n");
         txtareaBillprint.append("Treatmentcost LKR : "+ tretmentcost+"\n");
         txtareaBillprint.append("Advance payement LKR : "+ advacepayment+"\n");
         txtareaBillprint.append("Total amount LKR : "+totalamount+"\n");
         
       
    }//GEN-LAST:event_butPrintBillActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
   txtboxPatientname.setText(""); //Clear name 
   txtboxTelno.setText("");// Clear telephone numer 
   txtboxAddress.setText(""); //Clear address
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void checkboxApoimentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkboxApoimentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkboxApoimentActionPerformed

    private void advancePaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_advancePaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_advancePaymentActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       
         txtareaBillprint.setText(""); // clear the bill area
         txtboxTotalFee.setText("");// clear the toral treatment value
txtboxEnterID.setText("");// Clean the appoiment enter txt box
apoimentID=0;  // resest the apoiment vlue by the user
txtareaSearch.setText("");  // cleaning the txt area
comboserchSelectdate.setSelectedIndex(0); // clene the combo box
txtareaSearch.setText("");  // clear the txt area 

butTotalcostAction =false;   // Total bill button action deactivate

tretmentcost=0; //reset the varable 
advacepayment=0;//reset the varable
totalamount=0;//reset the varable



    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          ComboBoxTime.removeAllItems(); 
        int index=comboBoxDate.getSelectedIndex(); // get selected date index value
        int val=timearray[index][0];  // Assing to the varable;
        int y=timearray[index][1];    // get value of the array last value of the row
        for(int i= val; i<= y;i++){  // run for loop to get find available time range
      
            String stringdate=String.valueOf(i);
            ComboBoxTime.addItem(stringdate+".00PM"); // Set to combo box time range relavent to the each date
        //System.out.println("Value of i is"+i);       
        }
  
    }//GEN-LAST:event_jButton2ActionPerformed

    private void ComboBoxTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxTimeActionPerformed

    
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        
//        
//   
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Mainframe().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxTime;
    private javax.swing.JButton addtretment;
    private javax.swing.JTextField advancePayment;
    private javax.swing.JButton butClean;
    private javax.swing.JButton butPrintBill;
    private javax.swing.JButton butSearch;
    private javax.swing.JButton butTotalcost;
    private javax.swing.JCheckBox checkboxApoiment;
    private javax.swing.JComboBox<String> comboBoxDate;
    private javax.swing.JComboBox<String> comboBoxTreatment;
    private javax.swing.JComboBox<String> comboserchSelectdate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButtonMakeApoiment;
    private javax.swing.JButton jButtonRemoveTreatment;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel labelAdvancepayment;
    private javax.swing.JTextArea texareaTreatmentlist;
    private javax.swing.JTextArea txtareaBillprint;
    private javax.swing.JTextArea txtareaSearch;
    private javax.swing.JTextField txtboxAddress;
    private javax.swing.JTextField txtboxApoimnentID;
    private javax.swing.JTextField txtboxEnterID;
    private javax.swing.JTextField txtboxPatientname;
    private javax.swing.JTextField txtboxTelno;
    private javax.swing.JTextField txtboxTotalFee;
    // End of variables declaration//GEN-END:variables
}
